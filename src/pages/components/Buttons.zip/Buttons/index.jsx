import styled from "styled-components";
import * as React from 'react';
import styles from "./buttons.module.css"

export default function Chip({valueChip}){
    return(
        <div className={styles.ContentCheckbox}>
            <article className={styles.checkbox}>
                <input type="checkbox" value={valueChip}/>
                <div>
                    <span>
                    Desenvolvimento
                    </span>
                </div>
            </article>
        </div>
    );
}

export const ButtonProfile = styled.button`
    background-color: #fff;
    outline: none;
    border: solid 2px ${props => props.borda};
    color: ${props => props.corTexto};
    font-size: 1.4rem;
    padding: 2.5% 2vw;
    border-radius: 20rem;
`;

export const BoxButtonsArea = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: .5rem;

    >button{
        font-size: .85rem;
        font-weight: 500;
        white-space: nowrap;
        max-width: 30ch;
        overflow: hidden;
        text-overflow: ellipsis
    }
`;